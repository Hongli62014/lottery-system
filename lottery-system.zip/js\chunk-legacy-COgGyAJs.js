System.register([],function(t,r){"use strict";return{execute:function(){
/*!
       * is-plain-object <https://github.com/jonschlinkert/is-plain-object>
       *
       * Copyright (c) 2014-2017, Jon Schlinkert.
       * Released under the MIT License.
       */
function r(t){return"[object Object]"===Object.prototype.toString.call(t)}t("i",function(t){var e,o;return!1!==r(t)&&(void 0===(e=t.constructor)||!1!==r(o=e.prototype)&&!1!==o.hasOwnProperty("isPrototypeOf"))})}}});
