<script setup lang='ts'>
</script>

<template>
  <div>
    <button class="btn btn-error">
      打印
    </button>
  </div>
</template>

<style lang='scss' scoped>

</style>
