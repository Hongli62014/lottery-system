export const footerList = {
  data: [
    {
      id: 0,
      name: 'Github',
      url: 'https://github.com/LOG1997',
      icon: 'github',
    },
  ],
}
