export const navList = [
  {
    id: 0,
    name: '首页',
    url: 'home',
  },
  {
    id: 1,
    name: '项目',
    url: 'project',
  },
  {
    id: 2,
    name: '关于',
    url: 'about',
  },
]
