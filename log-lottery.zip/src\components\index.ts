export { default as Footer } from './Footer/index.vue'
/**
 *title: 自动导出组件
 */
export { default as Header } from './Header/index.vue'
