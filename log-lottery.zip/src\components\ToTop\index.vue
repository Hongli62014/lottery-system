<script setup lang='ts'>

</script>

<template>
  <div class="fixed z-50 flex items-center justify-center w-10 h-10 rounded-full shadow-lg cursor-pointer right-12 bottom-12 bg-slate-700 hover:bg-slate-600">
    <svg-icon name="toTop" />
  </div>
</template>

<style lang='scss' scoped>

</style>
