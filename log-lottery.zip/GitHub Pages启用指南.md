# GitHub Pages 启用指南

## 🔍 问题分析
您遇到的 404 错误是因为 GitHub Pages 尚未在仓库中启用。虽然我们已经配置了 GitHub Actions 工作流，但还需要在 GitHub 仓库设置中手动启用 Pages 功能。

## 📋 详细步骤

### 步骤 1：登录 GitHub
1. 访问 [GitHub](https://github.com/) 并登录您的账号
2. 进入您的仓库：`https://github.com/Hongli62014/lottery-system`

### 步骤 2：进入仓库设置
1. 点击仓库顶部的 `Settings` 选项卡
   ![Settings选项卡](https://static.w3cschool.cn/attachments/knowledge/202306/344423281528621.png)

### 步骤 3：找到 GitHub Pages 设置
1. 在左侧导航栏中，向下滚动找到 `Pages` 选项
   ![Pages选项](https://static.w3cschool.cn/attachments/knowledge/202306/344423281528622.png)

### 步骤 4：配置部署源
1. 在 `Build and deployment` 部分
2. `Source`（源）选择：`Deploy from a branch`
3. `Branch`（分支）选择：
   - **Branch**：`gh-pages`
   - **Folder**：`/ (root)`
4. 点击 `Save` 按钮保存设置
   ![配置部署源](https://static.w3cschool.cn/attachments/knowledge/202306/344423281528623.png)

### 步骤 5：等待部署完成
1. GitHub 会自动构建和部署您的网站
2. 首次部署需要 3-5 分钟
3. 部署完成后，您会看到：
   - ✅ `Your site is live at https://Hongli62014.github.io/lottery-system/`
   - 绿色的 `Active` 状态

## 🚀 验证部署

### 方式 1：直接访问
部署完成后，直接访问：`https://Hongli62014.github.io/lottery-system/`

### 方式 2：查看 GitHub Actions 状态
1. 进入仓库的 `Actions` 选项卡
2. 查看 `Deploy to GitHub Pages` 工作流的状态
3. 如果显示 ✅ `Success`，则部署成功

## 🔧 常见问题解决

### 问题 1：没有 gh-pages 分支？
- 等待 GitHub Actions 工作流完成，它会自动创建 gh-pages 分支
- 或手动运行工作流：
  1. 进入 `Actions` 选项卡
  2. 点击 `Deploy to GitHub Pages` 工作流
  3. 点击 `Run workflow` 按钮

### 问题 2：部署后仍显示 404？
1. 等待 5-10 分钟，GitHub Pages 缓存可能需要更新
2. 检查浏览器缓存，按 `Ctrl + F5` 强制刷新
3. 检查仓库名称是否正确
4. 检查 Pages 配置是否正确

### 问题 3：GitHub Actions 工作流失败？
1. 进入 `Actions` 选项卡查看错误日志
2. 常见错误：
   - Node.js 版本不兼容：检查 `.github/workflows/deploy.yml` 中的 node-version
   - 构建命令错误：确保使用 `npm run build:file`
   - 部署目录错误：确保使用 `./dist-file`

## 📱 替代方案

如果 GitHub Pages 部署遇到困难，您可以尝试：

### 1. Vercel 一键部署
- 访问 [Vercel](https://vercel.com/)
- 点击 `New Project` → `Import`
- 选择您的仓库 `Hongli62014/lottery-system`
- 点击 `Deploy`，等待部署完成

### 2. 本地直接使用
- 直接双击 `dist-file/index.html` 文件
- 在浏览器中打开即可使用
- 适合本地年会现场使用

## 📞 技术支持

如果您在操作过程中遇到任何问题，可以：
1. 查看 GitHub Pages [官方文档](https://docs.github.com/zh/pages)
2. 联系仓库维护者
3. 尝试使用替代部署方案

祝您部署成功！🎉