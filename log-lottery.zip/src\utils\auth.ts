export function getToken() {
  return window.localStorage.getItem('userToken')
}
